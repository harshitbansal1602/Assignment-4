<?php
require 'vars.inc.php';
require 'connect.inc.php';


?>

<html>

<head>
	<title>Login or Register!</title>
	<link rel="stylesheet" type="text/css" href="home.css"> 
</head>

<body>
	<div id="header">
	Congratulations, You have successfully Registered!
	</div>
	
	<div id="container_main">
	<div id="container">
		You can now login using this link <a href = "index.php">Login</a>.
	</div>
	<a href="logout.php">Logout</a>
	<div id="footer">
	</div>
	
</body>

</html>