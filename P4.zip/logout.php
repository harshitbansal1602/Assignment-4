<?php

require 'vars.inc.php';

session_destroy();
header('Location: index.php');
exit();


?>